# IS300Fall2022

Our repo for the portfolio website, a wire-frame to be completed by end of Fall quarter in 2022. :octocat:

- [x] Create Repo
- [ ] Add Java Script
